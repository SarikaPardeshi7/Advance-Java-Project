package com.DAO;
import java.sql.*;
import com.Entity.User;  // Because in this program, we are having "User" class present in com.Entity package.

public class UserDAO 
{
	private Connection con;
	public UserDAO(Connection con)
	{
		this.con = con;
	}
	
	public boolean userRegister(User u)
	{
		boolean status = false;
		try
		{
			String query = "insert into user(Name,Email,Password)values(?,?,?)";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, u.getName());   // Calling getter method of class "User". 
			ps.setString(2, u.getEmail());
			ps.setString(3, u.getPassword());
			int n = ps.executeUpdate();  // If the given DML statement is executed successfully, executeUpdate() method returns 1. 
			if(n==1)
			{
				status = true;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return status;
	}
	
	public User userLogin(String e, String p)
	{
		User u = null;
		try
		{
			String query = "select * from user where Email=? and Password=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, e);
			ps.setString(2, p);
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				u = new User();
				u.setId(rs.getInt(1));
				u.setName(rs.getString(2));
				u.setEmail(rs.getString(3));
				u.setPassword(rs.getString(4));
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return u;
	}
}
