package com.DAO;
import java.sql.*;
import com.Entity.Product;
import java.util.*;

public class ProductDAO 
{
	private Connection con;
	public ProductDAO(Connection con)
	{
		this.con=con;
	}
	
	// Add Product
	public boolean addProduct(Product p)
	{
		boolean status=false;
		try
		{
			String query = "insert into product(Name,Price,Image,Description)values(?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, p.getName());
			ps.setInt(2, p.getPrice());
			ps.setString(3, p.getImage());
			ps.setString(4, p.getDescirption());
			int n = ps.executeUpdate();
			if(n==1)
			{
				status=true;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return status;
	}
	
	// Edit Product
	public boolean editProduct(int id,String name,int price,String img,String descp)
	{
		boolean status=false;
		try
		{
			String query = "update product set Name=?, Price=?, Image=?, Description=? where Id=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, name);
			ps.setInt(2, price);
			ps.setString(3, img);
			ps.setString(4, descp);
			ps.setInt(5, id);
			int n = ps.executeUpdate();
			if(n==1)
			{
				status=true;
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return status;
	}
	
	// Delete Product
	public boolean deleteProduct(int id)
	{
		boolean status=false;
		try
		{
			String query = "delete from product where Id=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);
			int n = ps.executeUpdate();
			if(n==1)
			{
				status=true;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return status;
	}
	
	// Fetching products
	public List<Product> getAllProducts()
	{
		List<Product> products = new ArrayList<Product>();
		try
		{
			String query = "select * from product";
			Statement s = con.createStatement();
			ResultSet rs = s.executeQuery(query);
			while(rs.next())
			{
				Product p = new Product();
				p.setId(rs.getInt("Id"));
				p.setName(rs.getString("Name"));
				p.setPrice(rs.getInt("Price"));
				p.setImage(rs.getString("Image"));
                p.setDescription(rs.getString("Description"));	
                products.add(p);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return products;
	}
}
