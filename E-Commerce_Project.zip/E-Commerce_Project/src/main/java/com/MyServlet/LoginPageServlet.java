package com.MyServlet;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.DAO.UserDAO;
import com.MyConnection.DbConnection;
import com.Entity.User;

@WebServlet("/LoginPageServlet")
public class LoginPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public LoginPageServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		String email = request.getParameter("email");
		String pwd = request.getParameter("pwd");
		UserDAO ud = new UserDAO(DbConnection.getCon());
		User usr = ud.userLogin(email, pwd);
		HttpSession session = request.getSession();
		if(usr!=null)
			
		{
			session.setAttribute("user", usr);
			if(email.equals("admin@decor.in") && pwd.equals("Admin#567"))
				response.sendRedirect("AdminPanel.jsp");
			else
				response.sendRedirect("index.jsp");
		}
		else
		{
			session.setAttribute("logErrorMsg", "Invalid Email and Password!");
			response.sendRedirect("LoginPage.jsp");
		}
	}
}
