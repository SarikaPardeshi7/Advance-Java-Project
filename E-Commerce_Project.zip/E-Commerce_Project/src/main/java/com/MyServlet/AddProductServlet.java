package com.MyServlet;
import java.io.IOException;import com.mysql.cj.jdbc.Blob;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import com.Entity.Product;
import com.MyConnection.DbConnection;
import com.DAO.ProductDAO;

@MultipartConfig
@WebServlet("/AddProductServlet")
public class AddProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public AddProductServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		String name = request.getParameter("ProductName");
		int price = Integer.parseInt(request.getParameter("ProductPrice"));
		Part file = request.getPart("ProductImage");
		String img = file.getSubmittedFileName();
		String descp = request.getParameter("ProductDescription");
		if(descp.equals(""))
		{
			descp = "-";   // If admin did not added any description about the product, "-" is stored into the database.
		}
		Product p = new Product(name,price,img,descp);
		ProductDAO dao = new ProductDAO(DbConnection.getCon());
		boolean x = dao.addProduct(p);
		HttpSession session = request.getSession();
		if(x)
		{
			session.setAttribute("succMsg","Product added successfully!");
			response.sendRedirect("AdminPanel.jsp");
		}
		else
		{
			session.setAttribute("errorMsg","Something went wrong! Try again..");
			response.sendRedirect("AdminPanel.jsp");
		}
	}
}
