package com.MyServlet;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.ProductDAO;
import com.MyConnection.DbConnection;

@WebServlet("/DeleteProductServlet")
public class DeleteProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public DeleteProductServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		int id = Integer.parseInt(request.getParameter("id"));
		ProductDAO dao = new ProductDAO(DbConnection.getCon());
		boolean x = dao.deleteProduct(id);
		HttpSession session = request.getSession();
		if(x)
		{
			session.setAttribute("SMsg", "Product removed successfully!");
			response.sendRedirect("AdminPanel.jsp");
		}
		else
		{
			session.setAttribute("EMsg", "Something went wrong! Please, try again..");
			response.sendRedirect("AdminPanel.jsp");
		}
	}
}
