package com.MyConnection;
import java.sql.*;

public class DbConnection 
{
	private static Connection con;
	public static Connection getCon()
	{
		try
		{
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project_db","root","root");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}
}
